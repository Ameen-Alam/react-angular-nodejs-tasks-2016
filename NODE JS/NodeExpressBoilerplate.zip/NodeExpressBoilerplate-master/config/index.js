exports = module.exports = function (app) {
    app.set("mongodb-url", "mongodb://localhost:27017/SocketIo");
}